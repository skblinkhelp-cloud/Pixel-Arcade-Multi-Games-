# Android Mobile & Tablet Integration Guide (100% Fullscreen Support)

This Jigsaw Puzzle Arcade game is built as a self-contained, high-performance web game designed specifically to run at **100% full-screen** on every Android mobile phone, foldable, and tablet across all Android versions (Android 5 Lollipop to Android 14+).

---

## 1. Quick Build & Assets Export

Run the standard build command:
```bash
npm run build
```
This produces a production bundle in the `dist/` directory containing all HTML, CSS, JavaScript, and 12 optimized image assets.

Copy the contents of `dist/` into your Android project's assets folder:
```
android-project/app/src/main/assets/jigsaw_game/
  ├── index.html
  ├── assets/
  │   ├── index-*.js
  │   ├── index-*.css
  │   └── *.jpg
```

---

## 2. Jetpack Compose Integration (Edge-to-Edge 100% Screen)

In your Compose screen (`JigsawGameScreen.kt`):
```kotlin
package com.example.arcadegames.ui

import android.annotation.SuppressLint
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun JigsawGameScreen() {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )

                // Prevent bouncing and overscroll bars
                overScrollMode = View.OVER_SCROLL_NEVER

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true // Persists 50-stage unlocks & star records
                    databaseEnabled = true
                    allowFileAccess = true
                    mediaPlaybackRequiresUserGesture = false // Enables Web Audio SFX

                    // 100% Fullscreen viewport fitting for all Android screens
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    setSupportZoom(false)
                    builtInZoomControls = false
                    displayZoomControls = false

                    // Cache mode for offline performance
                    cacheMode = WebSettings.LOAD_DEFAULT
                }

                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()

                // Load from local assets - 100% offline, zero internet needed
                loadUrl("file:///android_asset/jigsaw_game/index.html")
            }
        }
    )
}
```

---

## 3. Traditional Android XML Activity (Full Immersive Mode)

In your `Activity` (`JigsawActivity.kt`):
```kotlin
package com.example.arcadegames

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class JigsawActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 100% Immersive Fullscreen on all Android versions
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        setContentView(R.layout.activity_jigsaw)

        webView = findViewById(R.id.gameWebView)
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        webView.webViewClient = WebViewClient()
        webView.loadUrl("file:///android_asset/jigsaw_game/index.html")
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
```

Layout `activity_jigsaw.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#050713">

    <WebView
        android:id="@+id/gameWebView"
        android:layout_width="match_parent"
        android:layout_height="match_parent" />
</FrameLayout>
```

---

## 4. Android Manifest Configurations
In `AndroidManifest.xml`:
```xml
<manifest ...>
    <!-- Optional: Haptic vibration feedback on piece snap -->
    <uses-permission android:name="android.permission.VIBRATE" />

    <application
        android:hardwareAccelerated="true"
        ...>
        <activity
            android:name=".JigsawActivity"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden"
            android:screenOrientation="fullSensor"
            android:theme="@style/Theme.AppCompat.NoActionBar" />
    </application>
</manifest>
```

---

## 5. Screen Adaptation Features
- **100% Display Across Aspect Ratios**: Uses `100dvh` and CSS `max-w-[min(96vw, 56vh)]` so the puzzle board and tray fit seamlessly on 20:9, 19.5:9, 18:9, 16:9 phones, and 4:3 / 16:10 tablets without black sidebars or scrolling.
- **`viewport-fit=cover`**: Adapts around camera punch-holes and notches using CSS `env(safe-area-inset-*)`.
- **Zero External Dependencies**: All 12 image assets, audio synthesizers, and 50 stages are bundled into the app for 100% offline play.
