import os
import zipfile
import shutil

# Ensure public directory exists
os.makedirs('public', exist_ok=True)
os.makedirs('dist', exist_ok=True)

# 1. Create android_jigsaw_game.zip (for Android Studio app assets)
android_zip_path = 'public/android_jigsaw_game.zip'
print("Creating Android Assets Zip:", android_zip_path)

with zipfile.ZipFile(android_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    # Add all files from dist
    for root, dirs, files in os.walk('dist'):
        for file in files:
            # Skip any existing zip files in dist
            if file.endswith('.zip'):
                continue
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, 'dist')
            zipf.write(file_path, arcname)
    
    # Also include the Android Integration Guide
    if os.path.exists('ANDROID_INTEGRATION.md'):
        zipf.write('ANDROID_INTEGRATION.md', 'ANDROID_INTEGRATION.md')

print("Created", android_zip_path, os.path.getsize(android_zip_path), "bytes")

# Copy to dist so it's also available in production build
shutil.copy(android_zip_path, 'dist/android_jigsaw_game.zip')

# 2. Create full source zip
source_zip_path = 'public/jigsaw_full_source.zip'
print("Creating Source Code Zip:", source_zip_path)

exclude_dirs = {'node_modules', '.git', 'dist'}
with zipfile.ZipFile(source_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        for file in files:
            if file.endswith('.zip'):
                continue
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, '.')
            zipf.write(file_path, arcname)

print("Created", source_zip_path, os.path.getsize(source_zip_path), "bytes")
shutil.copy(source_zip_path, 'dist/jigsaw_full_source.zip')
print("Successfully generated all zip packages!")
