/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { STAGES, Stage } from './types/stages';
import { ArcadeHUD } from './components/ArcadeHUD';
import { JigsawBoard } from './components/JigsawBoard';
import { ArcadeControls } from './components/ArcadeControls';
import { VictoryModal } from './components/VictoryModal';
import { StageSelectModal } from './components/StageSelectModal';
import { ZipDownloadModal } from './components/ZipDownloadModal';
import { MobileFrame } from './components/MobileFrame';
import { sound } from './utils/audio';

export default function App() {
  // Current active stage
  const [currentStageIdx, setCurrentStageIdx] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('pixel_jigsaw_last_stage');
      return saved ? Math.min(Math.max(parseInt(saved, 10), 0), STAGES.length - 1) : 0;
    } catch {
      return 0;
    }
  });

  const currentStage: Stage = STAGES[currentStageIdx] || STAGES[0];

  // Unlocked stages tracking (persisted)
  const [unlockedStages, setUnlockedStages] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem('pixel_jigsaw_unlocked');
      return saved ? JSON.parse(saved) : [1];
    } catch {
      return [1];
    }
  });

  // Star ratings earned per stage
  const [stageStars, setStageStars] = useState<Record<number, number>>(() => {
    try {
      const saved = localStorage.getItem('pixel_jigsaw_stars');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Game state
  const [score, setScore] = useState<number>(0);
  const [stageScore, setStageScore] = useState<number>(0);
  const [timeRemaining, setTimeRemaining] = useState<number>(currentStage.timeLimitSeconds);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [showGhostHint, setShowGhostHint] = useState<boolean>(false);
  const [showScanlines, setShowScanlines] = useState<boolean>(false);
  const [gridLineStyle, setGridLineStyle] = useState<'arcade-neon' | 'etched' | 'laser'>('arcade-neon');

  // Modals
  const [showVictoryModal, setShowVictoryModal] = useState<boolean>(false);
  const [showStageSelectModal, setShowStageSelectModal] = useState<boolean>(false);
  const [showZipModal, setShowZipModal] = useState<boolean>(false);
  const [earnedStars, setEarnedStars] = useState<number>(3);
  const [boardResetKey, setBoardResetKey] = useState<number>(0);

  // Free hint action registered from JigsawBoard
  const [freeHintFn, setFreeHintFn] = useState<(() => void) | null>(null);

  const handleRegisterHintAction = useCallback((fn: () => void) => {
    setFreeHintFn(() => fn);
  }, []);

  const handleTriggerFreeHint = useCallback(() => {
    if (freeHintFn) {
      freeHintFn();
    }
  }, [freeHintFn]);

  // Initialize or reset timer on stage change
  useEffect(() => {
    setTimeRemaining(currentStage.timeLimitSeconds);
    setStageScore(0);
    setShowVictoryModal(false);
    setShowGhostHint(false);
    try {
      localStorage.setItem('pixel_jigsaw_last_stage', currentStageIdx.toString());
    } catch {}
  }, [currentStageIdx, currentStage, boardResetKey]);

  // Stage countdown timer
  useEffect(() => {
    if (showVictoryModal) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [showVictoryModal, boardResetKey]);

  // Handle piece placed on board
  const handlePiecePlaced = useCallback((placedCount: number, totalCount: number) => {
    const pts = 100;
    setScore((s) => s + pts);
    setStageScore((s) => s + pts);
  }, []);

  // Handle stage completion
  const handleStageCompleted = useCallback(() => {
    const timePct = timeRemaining / currentStage.timeLimitSeconds;
    let stars = 1;
    if (timePct >= 0.5) stars = 3;
    else if (timePct >= 0.25) stars = 2;

    setEarnedStars(stars);

    // Save stars
    setStageStars((prev) => {
      const next = { ...prev, [currentStage.id]: Math.max(prev[currentStage.id] || 0, stars) };
      try {
        localStorage.setItem('pixel_jigsaw_stars', JSON.stringify(next));
      } catch {}
      return next;
    });

    // Unlock next stage if exists
    const nextStage = STAGES[currentStageIdx + 1];
    if (nextStage) {
      setUnlockedStages((prev) => {
        if (!prev.includes(nextStage.id)) {
          const next = [...prev, nextStage.id];
          try {
            localStorage.setItem('pixel_jigsaw_unlocked', JSON.stringify(next));
          } catch {}
          return next;
        }
        return prev;
      });
    }

    sound.playVictory();
    setShowVictoryModal(true);
  }, [currentStage, currentStageIdx, timeRemaining]);

  // Advance to Next Stage
  const handleNextStage = useCallback(() => {
    setShowVictoryModal(false);
    if (currentStageIdx + 1 < STAGES.length) {
      setCurrentStageIdx((idx) => idx + 1);
    }
  }, [currentStageIdx]);

  // Replay Current Stage
  const handleReplayStage = useCallback(() => {
    setShowVictoryModal(false);
    setBoardResetKey((k) => k + 1);
  }, []);

  // Select Stage from Map
  const handleSelectStage = useCallback((selectedStage: Stage) => {
    const idx = STAGES.findIndex((s) => s.id === selectedStage.id);
    if (idx !== -1) {
      setCurrentStageIdx(idx);
      setShowVictoryModal(false);
      setBoardResetKey((k) => k + 1);
    }
  }, []);

  // Toggle Sound
  const handleToggleSound = useCallback(() => {
    setSoundEnabled((prev) => {
      const next = !prev;
      sound.enabled = next;
      sound.hapticsEnabled = next;
      return next;
    });
  }, []);

  const hasNextStage = currentStageIdx + 1 < STAGES.length;

  return (
    <MobileFrame showScanlines={showScanlines}>
      {/* Top Arcade HUD Header with ZIP Download */}
      <ArcadeHUD
        stage={currentStage}
        totalStages={STAGES.length}
        score={score}
        timeRemaining={timeRemaining}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
        showGhostHint={showGhostHint}
        onToggleGhostHint={() => setShowGhostHint((h) => !h)}
        onOpenStageSelect={() => setShowStageSelectModal(true)}
        onRestartStage={handleReplayStage}
        onOpenZipModal={() => setShowZipModal(true)}
      />

      {/* Main Interactive Stage Puzzle Board & Piece Tray */}
      <main className="w-full flex-1 flex flex-col items-center justify-between py-0.5 sm:py-1 overflow-hidden">
        <JigsawBoard
          key={`${currentStage.id}-${boardResetKey}`}
          stage={currentStage}
          onPiecePlaced={handlePiecePlaced}
          onStageCompleted={handleStageCompleted}
          showGhostHint={showGhostHint}
          gridLineStyle={gridLineStyle}
          onRegisterHintAction={handleRegisterHintAction}
        />

        {/* Bottom Arcade Control Deck with prominent ZIP Button */}
        <ArcadeControls
          stage={currentStage}
          gridLineStyle={gridLineStyle}
          onChangeGridLineStyle={setGridLineStyle}
          showGhostHint={showGhostHint}
          onToggleGhostHint={() => setShowGhostHint((h) => !h)}
          onOpenStageSelect={() => setShowStageSelectModal(true)}
          onRestartStage={handleReplayStage}
          onTriggerFreeHint={handleTriggerFreeHint}
          onOpenZipModal={() => setShowZipModal(true)}
        />
      </main>

      {/* Stage Clear Victory Celebration Modal */}
      {showVictoryModal && (
        <VictoryModal
          stage={currentStage}
          hasNextStage={hasNextStage}
          score={stageScore}
          timeRemaining={timeRemaining}
          stars={earnedStars}
          onNextStage={handleNextStage}
          onReplayStage={handleReplayStage}
          onOpenStageSelect={() => {
            setShowVictoryModal(false);
            setShowStageSelectModal(true);
          }}
        />
      )}

      {/* Stage Select Map Modal (50 Stages) */}
      {showStageSelectModal && (
        <StageSelectModal
          currentStageId={currentStage.id}
          unlockedStages={unlockedStages}
          stageStars={stageStars}
          onSelectStage={handleSelectStage}
          onClose={() => setShowStageSelectModal(false)}
        />
      )}

      {/* Direct Zip Download Modal */}
      {showZipModal && (
        <ZipDownloadModal
          onClose={() => setShowZipModal(false)}
        />
      )}
    </MobileFrame>
  );
}
