import React from 'react';
import { Grid, Eye, RotateCcw, Sparkles, Download } from 'lucide-react';
import { sound } from '../utils/audio';
import { Stage } from '../types/stages';

interface ArcadeControlsProps {
  stage: Stage;
  gridLineStyle: 'arcade-neon' | 'etched' | 'laser';
  onChangeGridLineStyle: (style: 'arcade-neon' | 'etched' | 'laser') => void;
  showGhostHint: boolean;
  onToggleGhostHint: () => void;
  onOpenStageSelect: () => void;
  onRestartStage: () => void;
  onTriggerFreeHint?: () => void;
  onOpenZipModal: () => void;
}

export const ArcadeControls: React.FC<ArcadeControlsProps> = ({
  stage,
  gridLineStyle,
  onChangeGridLineStyle,
  showGhostHint,
  onToggleGhostHint,
  onOpenStageSelect,
  onRestartStage,
  onTriggerFreeHint,
  onOpenZipModal,
}) => {
  return (
    <footer className="w-full max-w-2xl mx-auto px-2 py-1 mt-auto select-none shrink-0">
      <div className="bg-slate-900/90 border border-cyan-400/40 rounded-xl p-1.5 sm:p-2 flex flex-wrap items-center justify-between gap-1.5 shadow-[0_0_15px_rgba(0,240,255,0.1)]">
        {/* Left: Quick Actions */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {/* Prominent ZIP Download Button */}
          <button
            onClick={() => {
              sound.playPickup();
              onOpenZipModal();
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-gradient-to-r from-emerald-500 to-green-400 hover:from-emerald-400 hover:to-green-300 text-slate-950 font-bold rounded-lg text-[9px] font-pixel transition-transform active:scale-95 cursor-pointer border border-emerald-200 shadow-[0_0_12px_rgba(16,185,129,0.5)]"
            title="Download ZIP File for Android"
          >
            <Download className="w-3 h-3 stroke-[2.5]" />
            <span>ZIP FILE</span>
          </button>

          <button
            onClick={() => {
              sound.playBleep();
              onOpenStageSelect();
            }}
            className="flex items-center gap-1 px-2 py-1.5 bg-purple-950/80 hover:bg-purple-900 text-purple-200 border border-purple-400/60 rounded-lg text-[9px] font-pixel transition-transform active:scale-95 cursor-pointer"
          >
            <Grid className="w-3 h-3 text-cyan-400" />
            <span>STAGES (50)</span>
          </button>

          {/* Free Hint Button */}
          {onTriggerFreeHint && (
            <button
              onClick={() => {
                onTriggerFreeHint();
              }}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-bold rounded-lg text-[9px] font-pixel transition-transform active:scale-95 cursor-pointer border border-yellow-300 shadow-[0_0_10px_rgba(250,204,21,0.5)]"
              title="Free Hint: Snaps a card into position"
            >
              <Sparkles className="w-3 h-3 fill-slate-950" />
              <span>FREE HINT</span>
            </button>
          )}

          {/* Peek Reference Image */}
          <button
            onClick={() => {
              sound.playBleep();
              onToggleGhostHint();
            }}
            className={`flex items-center gap-1 px-2 py-1.5 rounded-lg text-[9px] font-pixel transition-transform active:scale-95 cursor-pointer border ${
              showGhostHint
                ? 'bg-amber-950/80 text-yellow-300 border-yellow-400'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:border-slate-500'
            }`}
            title="Toggle faint background image preview"
          >
            <Eye className="w-3 h-3 text-yellow-400" />
            <span>{showGhostHint ? 'PEEK ON' : 'PEEK'}</span>
          </button>

          <button
            onClick={() => {
              sound.playBleep();
              onRestartStage();
            }}
            className="flex items-center gap-1 px-2 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-lg text-[9px] font-pixel transition-transform active:scale-95 cursor-pointer"
            title="Restart Stage"
          >
            <RotateCcw className="w-3 h-3 text-pink-400" />
            <span>RESET</span>
          </button>
        </div>

        {/* Right: Grid Lines Selector */}
        <div className="flex items-center gap-1 text-[9px] font-pixel">
          <span className="text-slate-500 hidden sm:inline">GRID:</span>
          <div className="flex bg-slate-950 p-0.5 rounded border border-purple-500/30">
            {(['arcade-neon', 'laser', 'etched'] as const).map((style) => (
              <button
                key={style}
                onClick={() => {
                  sound.playBleep();
                  onChangeGridLineStyle(style);
                }}
                className={`px-1.5 py-0.5 rounded text-[8px] font-pixel transition-all cursor-pointer ${
                  gridLineStyle === style
                    ? 'bg-purple-600 text-white shadow-[0_0_6px_#a855f7]'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {style === 'arcade-neon' ? 'NEON' : style === 'laser' ? 'LASER' : 'ETCH'}
              </button>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};
