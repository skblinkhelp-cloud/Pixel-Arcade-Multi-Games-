import React from 'react';
import { Volume2, VolumeX, Eye, Grid, RotateCcw, Download } from 'lucide-react';
import { sound } from '../utils/audio';
import { Stage } from '../types/stages';

interface ArcadeHUDProps {
  stage: Stage;
  totalStages: number;
  score: number;
  timeRemaining: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  showGhostHint: boolean;
  onToggleGhostHint: () => void;
  onOpenStageSelect: () => void;
  onRestartStage: () => void;
  onOpenZipModal: () => void;
}

export const ArcadeHUD: React.FC<ArcadeHUDProps> = ({
  stage,
  totalStages,
  score,
  timeRemaining,
  soundEnabled,
  onToggleSound,
  showGhostHint,
  onToggleGhostHint,
  onOpenStageSelect,
  onRestartStage,
  onOpenZipModal,
}) => {
  const formattedScore = score.toString().padStart(5, '0');
  const minutes = Math.floor(timeRemaining / 60);
  const seconds = timeRemaining % 60;
  const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

  return (
    <header className="w-full flex flex-col gap-1.5 pt-2 pb-2 px-3 sm:px-4 bg-slate-950/95 border-b-2 border-cyan-400/40 select-none">
      {/* Top Arcade Info Bar */}
      <div className="flex items-center justify-between text-[9px] sm:text-[10px] font-pixel text-purple-300">
        {/* Stage selection button */}
        <button
          onClick={() => {
            sound.playBleep();
            onOpenStageSelect();
          }}
          className="flex items-center gap-1.5 px-2 py-0.5 bg-purple-950/70 hover:bg-purple-900 border border-purple-400/60 rounded text-cyan-300 transition-colors cursor-pointer"
        >
          <Grid className="w-3 h-3 text-cyan-400" />
          <span>STAGE {stage.id}/{totalStages}: {stage.title.toUpperCase()}</span>
        </button>

        {/* Prominent ZIP Download Button in Top Bar */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              sound.playPickup();
              onOpenZipModal();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-emerald-500 to-green-400 hover:from-emerald-400 hover:to-green-300 text-slate-950 font-bold rounded-md font-pixel text-[8px] sm:text-[9px] border border-emerald-200 shadow-[0_0_10px_rgba(16,185,129,0.5)] cursor-pointer active:scale-95"
            title="Download Game in ZIP File"
          >
            <Download className="w-3 h-3 stroke-[2.5]" />
            <span>ZIP FILE</span>
          </button>
          <span className="text-yellow-400 font-pixel text-[8px] hidden sm:inline">{stage.difficulty.toUpperCase()}</span>
        </div>
      </div>

      {/* Main HUD Row: Score, Actions, Timer */}
      <div className="flex items-center justify-between gap-2 py-1 px-3 bg-slate-900/90 rounded-lg border-2 border-purple-500/50 shadow-[0_0_15px_rgba(168,85,247,0.2)]">
        {/* SCORE */}
        <div className="flex items-baseline gap-1.5">
          <span className="text-[9px] sm:text-[10px] font-pixel text-purple-400">SCORE:</span>
          <span className="text-sm sm:text-lg font-pixel text-yellow-300 tracking-wider drop-shadow-[0_0_6px_rgba(253,224,71,0.6)]">
            {formattedScore}
          </span>
        </div>

        {/* Center Action Controls */}
        <div className="flex items-center gap-1.5">
          {/* Peek Ghost Hint */}
          <button
            onClick={() => {
              sound.playBleep();
              onToggleGhostHint();
            }}
            title={showGhostHint ? "Hide Reference" : "Peek Reference"}
            className={`p-1.5 rounded text-xs transition-colors cursor-pointer ${
              showGhostHint
                ? 'bg-amber-500/30 text-yellow-300 border border-yellow-400'
                : 'bg-slate-800 text-slate-300 hover:text-cyan-300 border border-slate-700'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
          </button>

          {/* Restart Stage */}
          <button
            onClick={() => {
              sound.playBleep();
              onRestartStage();
            }}
            title="Restart Stage"
            className="p-1.5 rounded text-xs bg-slate-800 text-slate-300 hover:text-pink-300 border border-slate-700 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => {
              onToggleSound();
              sound.playBleep();
            }}
            title={soundEnabled ? "Sound ON" : "Sound Muted"}
            className={`p-1.5 rounded text-xs transition-colors cursor-pointer ${
              soundEnabled
                ? 'bg-emerald-500/30 text-emerald-300 border border-emerald-400'
                : 'bg-slate-800 text-slate-500 border border-slate-700'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* TIMER */}
        <div className="flex items-baseline gap-1.5">
          <span className="text-[9px] sm:text-[10px] font-pixel text-purple-400">TIME:</span>
          <span className={`text-sm sm:text-lg font-pixel tracking-wider ${
            timeRemaining <= 30
              ? 'text-red-400 animate-pulse drop-shadow-[0_0_6px_rgba(248,113,113,0.8)]'
              : 'text-cyan-300 drop-shadow-[0_0_6px_rgba(103,232,249,0.5)]'
          }`}>
            {formattedTime}
          </span>
        </div>
      </div>
    </header>
  );
};
