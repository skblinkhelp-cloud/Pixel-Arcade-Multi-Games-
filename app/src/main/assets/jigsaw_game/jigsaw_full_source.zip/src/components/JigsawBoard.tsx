import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Stage } from '../types/stages';
import { PieceData, generatePuzzlePieces } from '../utils/jigsawGenerator';
import { sound } from '../utils/audio';
import { Sparkles, Check, ChevronLeft, ChevronRight, Shuffle } from 'lucide-react';

interface JigsawBoardProps {
  stage: Stage;
  onPiecePlaced: (placedCount: number, totalCount: number) => void;
  onStageCompleted: () => void;
  showGhostHint: boolean;
  gridLineStyle: 'arcade-neon' | 'etched' | 'laser';
  onRegisterHintAction?: (hintFn: () => void) => void;
}

// Fisher-Yates array shuffle for true scrambling
function shuffleArray<T>(array: T[]): T[] {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export const JigsawBoard: React.FC<JigsawBoardProps> = ({
  stage,
  onPiecePlaced,
  onStageCompleted,
  showGhostHint,
  gridLineStyle,
  onRegisterHintAction,
}) => {
  const [pieces, setPieces] = useState<PieceData[]>([]);
  const [placedPieceIds, setPlacedPieceIds] = useState<Set<string>>(new Set());
  const [selectedPieceId, setSelectedPieceId] = useState<string | null>(null);
  const [trayFilter, setTrayFilter] = useState<'all' | 'edges' | 'interior'>('all');
  // Shuffled order of piece IDs for the tray
  const [trayOrder, setTrayOrder] = useState<string[]>([]);

  // Dragging state
  const boardRef = useRef<HTMLDivElement>(null);
  const trayRef = useRef<HTMLDivElement>(null);
  const [draggedPieceId, setDraggedPieceId] = useState<string | null>(null);
  const [dragPos, setDragPos] = useState<{ x: number; y: number } | null>(null);
  const [snapEffect, setSnapEffect] = useState<{ x: number; y: number; label?: string } | null>(null);

  // Generate and thoroughly shuffle pieces when stage changes
  useEffect(() => {
    const config = {
      cols: stage.cols,
      rows: stage.rows,
      width: stage.width,
      height: stage.height,
    };
    const generated = generatePuzzlePieces(config, 100 + stage.id * 31);
    setPieces(generated);

    // Warmup anchor piece only for stage 1
    const initialPlaced = new Set<string>();
    if (stage.id === 1 && generated.length > 0) {
      initialPlaced.add(generated[0].id);
    }
    setPlacedPieceIds(initialPlaced);

    // Scramble / shuffle the piece order in the tray
    const pieceIds = generated.map((p) => p.id);
    setTrayOrder(shuffleArray(pieceIds));

    setSelectedPieceId(null);
    setDraggedPieceId(null);
    setDragPos(null);
    setTrayFilter('all');
  }, [stage]);

  // Reshuffle unplaced cards in the tray on user demand
  const handleShuffleTray = useCallback(() => {
    sound.playPickup();
    setTrayOrder((prev) => shuffleArray(prev));
  }, []);

  // Map piece IDs in their shuffled order to piece objects
  const unplacedPiecesInShuffledOrder = trayOrder
    .map((id) => pieces.find((p) => p.id === id))
    .filter((p): p is PieceData => !!p && !placedPieceIds.has(p.id));

  const totalPieces = pieces.length;
  const placedCount = placedPieceIds.size;

  // Filtered tray pieces (for 12+ pieces, Edge/Interior filtering)
  const visibleTrayPieces = unplacedPiecesInShuffledOrder.filter((p) => {
    const isEdge = p.top === 0 || p.right === 0 || p.bottom === 0 || p.left === 0;
    if (trayFilter === 'edges') return isEdge;
    if (trayFilter === 'interior') return !isEdge;
    return true;
  });

  // Notify parent of progress
  useEffect(() => {
    if (totalPieces > 0) {
      onPiecePlaced(placedCount, totalPieces);
      if (placedCount === totalPieces) {
        const timer = setTimeout(() => {
          onStageCompleted();
        }, 600);
        return () => clearTimeout(timer);
      }
    }
  }, [placedCount, totalPieces, onPiecePlaced, onStageCompleted]);

  // Check if position is near a piece's target slot
  const checkSlotProximity = useCallback(
    (clientX: number, clientY: number, piece: PieceData) => {
      if (!boardRef.current) return false;
      const rect = boardRef.current.getBoundingClientRect();
      const scaleX = rect.width / stage.width;
      const scaleY = rect.height / stage.height;

      const slotCenterX = rect.left + (piece.originX + piece.width / 2) * scaleX;
      const slotCenterY = rect.top + (piece.originY + piece.height / 2) * scaleY;

      const dist = Math.hypot(clientX - slotCenterX, clientY - slotCenterY);
      const pieceScreenW = piece.width * scaleX;
      const threshold = Math.max(pieceScreenW * 0.75, 45);
      return dist < threshold;
    },
    [stage]
  );

  // Snap piece into board
  const snapPiece = useCallback(
    (piece: PieceData, isFreeHint: boolean = false) => {
      sound.playSnap();
      setPlacedPieceIds((prev) => {
        const next = new Set(prev);
        next.add(piece.id);
        return next;
      });
      setSelectedPieceId(null);

      // Trigger sparkle particle at slot
      if (boardRef.current) {
        const rect = boardRef.current.getBoundingClientRect();
        const scaleX = rect.width / stage.width;
        const scaleY = rect.height / stage.height;
        setSnapEffect({
          x: (piece.originX + piece.width / 2) * scaleX,
          y: (piece.originY + piece.height / 2) * scaleY,
          label: isFreeHint ? 'FREE HINT PLACED!' : '+100 PTS!',
        });
        setTimeout(() => setSnapEffect(null), 1100);
      }
    },
    [stage]
  );

  // FREE HINT: Instantly snaps a card into its correct place (zero cost/penalty)
  const handleFreeHint = useCallback(() => {
    if (unplacedPiecesInShuffledOrder.length === 0) return;
    // If a piece is selected in tray, snap that piece; otherwise snap the first unplaced piece
    const targetPiece =
      unplacedPiecesInShuffledOrder.find((p) => p.id === selectedPieceId) ||
      unplacedPiecesInShuffledOrder[0];
    if (targetPiece) {
      snapPiece(targetPiece, true);
    }
  }, [unplacedPiecesInShuffledOrder, selectedPieceId, snapPiece]);

  // Register hint action callback with parent if requested
  useEffect(() => {
    if (onRegisterHintAction) {
      onRegisterHintAction(handleFreeHint);
    }
  }, [onRegisterHintAction, handleFreeHint]);

  // Pointer Down on Tray Piece (Start Drag or Select)
  const handlePointerDownPiece = (e: React.PointerEvent, piece: PieceData) => {
    e.preventDefault();
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    sound.playPickup();

    setSelectedPieceId(piece.id);
    setDraggedPieceId(piece.id);
    setDragPos({ x: e.clientX, y: e.clientY });
  };

  // Pointer Move (Dragging) - ZERO slot highlighting or clues
  const handlePointerMove = (e: React.PointerEvent) => {
    if (!draggedPieceId) return;
    setDragPos({ x: e.clientX, y: e.clientY });
  };

  // Pointer Up (Drop or Tap)
  const handlePointerUp = (e: React.PointerEvent) => {
    if (!draggedPieceId) return;

    const piece = pieces.find((p) => p.id === draggedPieceId);
    if (piece && checkSlotProximity(e.clientX, e.clientY, piece)) {
      snapPiece(piece);
    } else {
      sound.playDrop();
    }

    setDraggedPieceId(null);
    setDragPos(null);
  };

  // Click on Board Slot when a piece is selected (Tap-to-Place)
  // ZERO hints: does NOT reveal if wrong slot is clicked
  const handleSlotClick = (piece: PieceData) => {
    if (placedPieceIds.has(piece.id)) return;

    if (selectedPieceId === piece.id) {
      // User tapped the correct slot matching their selected piece
      snapPiece(piece);
    } else if (selectedPieceId) {
      // User tapped an incorrect slot: no snap, no clue given
      sound.playDrop();
    }
  };

  // Quick tray scroll
  const scrollTray = (dir: 'left' | 'right') => {
    if (trayRef.current) {
      const shift = dir === 'left' ? -200 : 200;
      trayRef.current.scrollBy({ left: shift, behavior: 'smooth' });
    }
  };

  // Grid stroke styles
  const gridStroke = {
    'arcade-neon': {
      stroke: 'rgba(0, 240, 255, 0.75)',
      width: totalPieces >= 25 ? 1.2 : totalPieces >= 16 ? 1.6 : 2.2,
      glow: 'drop-shadow(0 0 3px rgba(0, 240, 255, 0.8))',
    },
    'laser': {
      stroke: 'rgba(236, 72, 153, 0.85)',
      width: totalPieces >= 25 ? 1.1 : totalPieces >= 16 ? 1.5 : 2,
      glow: 'drop-shadow(0 0 4px rgba(236, 72, 153, 0.9))',
    },
    'etched': {
      stroke: 'rgba(255, 255, 255, 0.65)',
      width: totalPieces >= 25 ? 1.0 : totalPieces >= 16 ? 1.3 : 1.8,
      glow: 'drop-shadow(0 1px 1px rgba(0, 0, 0, 0.9))',
    },
  }[gridLineStyle];

  const draggedPiece = pieces.find((p) => p.id === draggedPieceId);

  // Dynamic tray piece size based on total piece count
  const trayItemSize = totalPieces <= 9 ? 76 : totalPieces <= 16 ? 64 : totalPieces <= 25 ? 54 : 46;

  return (
    <div
      className="relative w-full flex flex-col items-center select-none touch-none"
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      {/* Central Puzzle Board Container */}
      <div className="relative w-full flex flex-col items-center px-2 py-1">
        {/* Progress Tracker Bar with prominent FREE HINT Button */}
        <div className="w-full max-w-[560px] flex items-center justify-between mb-1.5 px-2 text-[10px] font-pixel text-slate-300">
          <div className="flex items-center gap-1.5">
            <span className="text-cyan-400">PROGRESS:</span>
            <span className="text-yellow-300 font-bold">
              {placedCount} / {totalPieces}
            </span>
            <span className="text-slate-500 font-screen">
              ({Math.round((placedCount / (totalPieces || 1)) * 100)}%)
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* 100% Free Hint Button */}
            <button
              onClick={handleFreeHint}
              disabled={unplacedPiecesInShuffledOrder.length === 0}
              className="flex items-center gap-1.5 text-[9px] sm:text-[10px] font-pixel text-slate-950 font-bold bg-gradient-to-r from-yellow-400 to-amber-300 hover:from-yellow-300 hover:to-amber-200 px-3 py-1 rounded-lg border-2 border-yellow-200 shadow-[0_0_12px_rgba(250,204,21,0.6)] cursor-pointer active:scale-95 disabled:opacity-40"
              title="Click to get free hint! Snaps a card into position"
            >
              <Sparkles className="w-3.5 h-3.5 fill-slate-950" />
              <span>FREE HINT</span>
            </button>
          </div>
        </div>

        {/* The Puzzle Board Box with Neon Arcade Borders */}
        <div
          ref={boardRef}
          className="relative bg-slate-950 border-3 sm:border-4 border-purple-500 rounded-xl shadow-[0_0_25px_rgba(168,85,247,0.35)] overflow-hidden w-full max-w-[min(96vw,50vh)] max-h-[50vh] sm:max-w-[min(94vw,56vh)] sm:max-h-[56vh]"
          style={{
            aspectRatio: `${stage.width} / ${stage.height}`,
            boxShadow: '0 0 0 2.5px #00f0ff, 0 0 20px rgba(0, 240, 255, 0.35)',
          }}
        >
          {/* SVG Definitions for piece clip paths */}
          <svg className="absolute w-0 h-0 pointer-events-none" aria-hidden="true">
            <defs>
              {pieces.map((p) => (
                <clipPath id={`clip-${p.id}`} key={`clip-${p.id}`} clipPathUnits="userSpaceOnUse">
                  <path d={p.pathD} />
                </clipPath>
              ))}
              {pieces.map((p) => (
                <clipPath id={`local-clip-${p.id}`} key={`local-clip-${p.id}`} clipPathUnits="userSpaceOnUse">
                  <path d={p.localPathD} />
                </clipPath>
              ))}
            </defs>
          </svg>

          {/* Ghost Preview Image (only shown if user explicitly turned on Peek Hint) */}
          <div
            className="absolute inset-0 pixel-crisp pointer-events-none transition-opacity duration-300"
            style={{
              backgroundImage: `url(${stage.imageUrl})`,
              backgroundSize: '100% 100%',
              opacity: showGhostHint ? 0.65 : 0.06,
              filter: showGhostHint ? 'brightness(1.1) saturate(1.1)' : 'grayscale(1) brightness(0.2)',
            }}
          />

          {/* SVG Board */}
          <svg
            viewBox={`0 0 ${stage.width} ${stage.height}`}
            className="w-full h-full block relative z-10"
          >
            {/* 1. Unplaced Slots (Cavities) - ALL IDENTICAL, ZERO HINTS OR CLUES */}
            {pieces.map((p) => {
              const isPlaced = placedPieceIds.has(p.id);
              if (isPlaced) return null;

              return (
                <g
                  key={`slot-${p.id}`}
                  onClick={() => handleSlotClick(p)}
                  className="cursor-pointer"
                >
                  {/* Uniform neutral cavity with no clues */}
                  <path
                    d={p.pathD}
                    fill="rgba(6, 9, 22, 0.92)"
                    stroke="rgba(0, 0, 0, 0.85)"
                    strokeWidth={totalPieces >= 25 ? '1.5' : totalPieces >= 16 ? '2' : '3'}
                  />

                  {/* Subtle uniform puzzle boundary line (same for all slots) */}
                  <path
                    d={p.pathD}
                    fill="none"
                    stroke="rgba(0, 240, 255, 0.22)"
                    strokeWidth={totalPieces >= 25 ? '0.8' : '1.2'}
                    strokeDasharray="4,4"
                  />
                </g>
              );
            })}

            {/* 2. Placed Pieces */}
            {pieces.map((p) => {
              const isPlaced = placedPieceIds.has(p.id);
              if (!isPlaced) return null;

              return (
                <g key={`placed-${p.id}`}>
                  <image
                    href={stage.imageUrl}
                    x="0"
                    y="0"
                    width={stage.width}
                    height={stage.height}
                    clipPath={`url(#clip-${p.id})`}
                    preserveAspectRatio="none"
                    className="pixel-crisp"
                  />

                  <path
                    d={p.pathD}
                    fill="none"
                    stroke="rgba(0, 0, 0, 0.6)"
                    strokeWidth={totalPieces >= 25 ? '1.2' : totalPieces >= 16 ? '1.6' : '2.5'}
                  />
                  <path
                    d={p.pathD}
                    fill="none"
                    stroke="rgba(255, 255, 255, 0.3)"
                    strokeWidth="0.8"
                    strokeDasharray="6, 5"
                  />
                </g>
              );
            })}

            {/* 3. Interlocking Grid Lines Overlay */}
            {pieces.map((p) => (
              <path
                key={`grid-line-${p.id}`}
                d={p.pathD}
                fill="none"
                stroke={gridStroke.stroke}
                strokeWidth={gridStroke.width}
                className="pointer-events-none transition-all duration-300"
                style={{ filter: gridStroke.glow }}
              />
            ))}
          </svg>

          {/* Sparkle celebration on snap */}
          {snapEffect && (
            <div
              className="absolute pointer-events-none z-30 transform -translate-x-1/2 -translate-y-1/2 animate-bounce"
              style={{ left: `${snapEffect.x}px`, top: `${snapEffect.y}px` }}
            >
              <div className="relative flex flex-col items-center">
                <span className="font-pixel text-[9px] text-yellow-300 bg-slate-900/95 px-2 py-0.5 rounded border border-yellow-400 shadow-[0_0_10px_#facc15] whitespace-nowrap">
                  {snapEffect.label || 'SNAP!'}
                </span>
                <Sparkles className="w-6 h-6 text-cyan-300 animate-spin" />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Piece Tray with Shuffled Cards */}
      <div className="w-full max-w-[560px] mt-1.5 px-2">
        <div className="bg-slate-900/95 border-2 border-purple-500/70 rounded-xl p-2 shadow-[0_0_15px_rgba(168,85,247,0.2)]">
          <div className="flex items-center justify-between pb-1 px-1 border-b border-purple-500/30 text-[9px] font-pixel text-purple-300">
            <div className="flex items-center gap-1.5">
              <span className="text-cyan-300">
                TRAY ({unplacedPiecesInShuffledOrder.length})
              </span>
              <button
                onClick={handleShuffleTray}
                title="Reshuffle cards in tray"
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-yellow-300 cursor-pointer"
              >
                <Shuffle className="w-2.5 h-2.5" />
              </button>
            </div>

            {/* Filter Buttons for 12+ pieces */}
            {totalPieces >= 12 && (
              <div className="flex items-center gap-1">
                {(['all', 'edges', 'interior'] as const).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => {
                      sound.playBleep();
                      setTrayFilter(mode);
                    }}
                    className={`px-1.5 py-0.5 rounded text-[8px] font-pixel transition-colors cursor-pointer ${
                      trayFilter === mode
                        ? 'bg-cyan-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {mode.toUpperCase()}
                  </button>
                ))}
              </div>
            )}

            <div className="flex items-center gap-1">
              <button
                onClick={() => scrollTray('left')}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                title="Scroll Left"
              >
                <ChevronLeft className="w-3 h-3" />
              </button>
              <button
                onClick={() => scrollTray('right')}
                className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer"
                title="Scroll Right"
              >
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Shuffled & Mixed Up Tray Items */}
          <div
            ref={trayRef}
            className="flex items-center gap-2 overflow-x-auto py-2 px-1 min-h-[80px] scrollbar-thin scrollbar-thumb-purple-600"
          >
            {visibleTrayPieces.length > 0 ? (
              visibleTrayPieces.map((piece) => {
                const isSelected = selectedPieceId === piece.id;
                const isDragging = draggedPieceId === piece.id;

                return (
                  <div
                    key={piece.id}
                    onPointerDown={(e) => handlePointerDownPiece(e, piece)}
                    onClick={() => {
                      setSelectedPieceId((prev) => (prev === piece.id ? null : piece.id));
                      sound.playPickup();
                    }}
                    className={`shrink-0 relative rounded-lg p-1 transition-all cursor-grab active:cursor-grabbing select-none ${
                      isSelected
                        ? 'bg-purple-900/70 ring-2 ring-yellow-400 scale-105 shadow-[0_0_10px_#facc15]'
                        : 'bg-slate-950/80 border border-slate-700 hover:border-cyan-400'
                    } ${isDragging ? 'opacity-30' : ''}`}
                    style={{
                      width: `${trayItemSize + 8}px`,
                      height: `${trayItemSize + 8}px`,
                      touchAction: 'none',
                    }}
                  >
                    <svg
                      viewBox={`-15 -15 ${piece.width + 30} ${piece.height + 30}`}
                      className="w-full h-full overflow-visible"
                    >
                      <path
                        d={piece.localPathD}
                        fill="none"
                        stroke={isSelected ? '#facc15' : '#00f0ff'}
                        strokeWidth="2.8"
                        style={{
                          filter: isSelected
                            ? 'drop-shadow(0 0 5px #facc15)'
                            : 'drop-shadow(0 0 3px #00f0ff)',
                        }}
                      />

                      <g clipPath={`url(#local-clip-${piece.id})`}>
                        <image
                          href={stage.imageUrl}
                          x={-piece.originX}
                          y={-piece.originY}
                          width={stage.width}
                          height={stage.height}
                          preserveAspectRatio="none"
                          className="pixel-crisp"
                        />
                      </g>

                      <path
                        d={piece.localPathD}
                        fill="none"
                        stroke="#ffffff"
                        strokeWidth="1"
                        strokeDasharray="4,4"
                      />
                    </svg>

                    {isSelected && (
                      <div className="absolute -top-1.5 -right-1 bg-yellow-400 text-slate-950 font-pixel text-[6px] px-1 rounded shadow font-bold">
                        SELECTED
                      </div>
                    )}
                  </div>
                );
              })
            ) : unplacedPiecesInShuffledOrder.length > 0 ? (
              <div className="w-full flex items-center justify-center py-3 text-slate-400 text-[10px] font-screen">
                No pieces in {trayFilter.toUpperCase()} filter. Switch to ALL.
              </div>
            ) : (
              <div className="w-full flex items-center justify-center gap-2 py-3 text-emerald-400 font-pixel text-xs">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>STAGE COMPLETE!</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Floating Dragged Element under Pointer (Zero board slot clues) */}
      {draggedPieceId && dragPos && draggedPiece && (
        <div
          className="fixed pointer-events-none z-50 transform -translate-x-1/2 -translate-y-1/2"
          style={{
            left: `${dragPos.x}px`,
            top: `${dragPos.y}px`,
            width: `${draggedPiece.width * 0.7}px`,
            height: `${draggedPiece.height * 0.7}px`,
          }}
        >
          <svg
            viewBox={`-15 -15 ${draggedPiece.width + 30} ${draggedPiece.height + 30}`}
            className="w-full h-full overflow-visible"
          >
            <path
              d={draggedPiece.localPathD}
              fill="none"
              stroke="#00f0ff"
              strokeWidth="4"
              style={{ filter: 'drop-shadow(0 0 10px #00f0ff)' }}
            />

            <g clipPath={`url(#local-clip-${draggedPiece.id})`}>
              <image
                href={stage.imageUrl}
                x={-draggedPiece.originX}
                y={-draggedPiece.originY}
                width={stage.width}
                height={stage.height}
                preserveAspectRatio="none"
                className="pixel-crisp"
              />
            </g>

            <path
              d={draggedPiece.localPathD}
              fill="none"
              stroke="#ffffff"
              strokeWidth="2"
            />
          </svg>
        </div>
      )}
    </div>
  );
};
