import React from 'react';

interface MobileFrameProps {
  children: React.ReactNode;
  showScanlines: boolean;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({ children, showScanlines }) => {
  return (
    <div className="w-full h-full min-h-screen min-h-[100dvh] max-h-[100dvh] flex flex-col bg-[#050713] text-slate-100 select-none overflow-hidden safe-top safe-bottom">
      {/* 100% full screen across all Android mobile screens and tablets without black sidebars */}
      <div className={`w-full h-full flex-1 flex flex-col bg-slate-950 overflow-hidden relative ${showScanlines ? 'arcade-crt' : ''}`}>
        {children}
      </div>
    </div>
  );
};
