import React, { useState } from 'react';
import { Stage, STAGES } from '../types/stages';
import { X, Star, Lock, Trophy, Download } from 'lucide-react';
import { sound } from '../utils/audio';

interface StageSelectModalProps {
  currentStageId: number;
  unlockedStages: number[];
  stageStars: Record<number, number>;
  onSelectStage: (stage: Stage) => void;
  onClose: () => void;
}

export const StageSelectModal: React.FC<StageSelectModalProps> = ({
  currentStageId,
  unlockedStages,
  stageStars,
  onSelectStage,
  onClose,
}) => {
  const [selectedWorld, setSelectedWorld] = useState<number>(0); // 0 = all

  const totalStars = Object.values(stageStars).reduce((acc, s) => acc + s, 0);

  const worlds = [
    { id: 0, label: 'ALL 50' },
    { id: 1, label: 'W1: 4-6P' },
    { id: 2, label: 'W2: 9P' },
    { id: 3, label: 'W3: 12-16P' },
    { id: 4, label: 'W4: 20P' },
    { id: 5, label: 'W5: 24-25P' },
    { id: 6, label: 'W6: 30P' },
    { id: 7, label: 'W7: 36P' },
    { id: 8, label: 'W8: 42-48P' },
  ];

  const filteredStages =
    selectedWorld === 0
      ? STAGES
      : STAGES.filter((s) => s.world === selectedWorld);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-sm animate-fadeIn select-none">
      <div className="relative w-full max-w-2xl bg-slate-950 border-4 border-cyan-400 rounded-2xl p-3 sm:p-5 shadow-[0_0_35px_rgba(0,240,255,0.4)] flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-2 border-b-2 border-purple-500/50 mb-2">
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-400" />
            <h2 className="font-pixel text-xs sm:text-sm text-yellow-300 tracking-wider">
              50 PUZZLE STAGES
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-slate-900 border border-yellow-400/50 px-2 py-0.5 rounded text-[10px] font-pixel text-yellow-300">
              <Star className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
              <span>{totalStars} / {STAGES.length * 3}</span>
            </div>

            <button
              onClick={() => {
                sound.playBleep();
                onClose();
              }}
              className="p-1 text-slate-400 hover:text-white rounded bg-slate-900 border border-slate-700 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* World Filter Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto py-1.5 mb-2 scrollbar-none">
          {worlds.map((w) => (
            <button
              key={w.id}
              onClick={() => {
                sound.playBleep();
                setSelectedWorld(w.id);
              }}
              className={`shrink-0 px-2.5 py-1 rounded text-[9px] font-pixel transition-colors cursor-pointer ${
                selectedWorld === w.id
                  ? 'bg-purple-600 text-white shadow-[0_0_8px_#a855f7] border border-purple-300'
                  : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
              }`}
            >
              {w.label}
            </button>
          ))}
        </div>

        {/* Stages Grid (Responsive columns for phone and tablet) */}
        <div className="flex-1 overflow-y-auto pr-1 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 py-1">
          {filteredStages.map((stage) => {
            const isUnlocked = unlockedStages.includes(stage.id);
            const isCurrent = stage.id === currentStageId;
            const stars = stageStars[stage.id] || 0;
            const pieceCount = stage.cols * stage.rows;

            return (
              <div
                key={stage.id}
                onClick={() => {
                  if (isUnlocked) {
                    sound.playPickup();
                    onSelectStage(stage);
                    onClose();
                  }
                }}
                className={`relative rounded-xl border-2 p-2 flex flex-col justify-between transition-all ${
                  isCurrent
                    ? 'bg-slate-900 border-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.4)] ring-2 ring-cyan-300/40'
                    : isUnlocked
                    ? 'bg-slate-900/70 border-purple-500/50 hover:border-purple-400 hover:bg-slate-900 cursor-pointer active:scale-95'
                    : 'bg-slate-950/80 border-slate-800 opacity-50 cursor-not-allowed'
                }`}
              >
                {/* Thumbnail */}
                <div className="relative aspect-video rounded-lg overflow-hidden border border-slate-700 mb-1.5">
                  <img
                    src={stage.imageUrl}
                    alt={stage.title}
                    className="w-full h-full object-cover pixel-crisp"
                  />
                  {!isUnlocked && (
                    <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center gap-1">
                      <Lock className="w-5 h-5 text-slate-400" />
                      <span className="font-pixel text-[7px] text-slate-300">LOCKED</span>
                    </div>
                  )}

                  {/* Piece count badge */}
                  <div className="absolute bottom-1 right-1 bg-black/85 font-pixel text-[8px] text-yellow-300 px-1 py-0.5 rounded border border-yellow-400/50">
                    {pieceCount}P
                  </div>

                  <div className="absolute top-1 left-1 bg-purple-950/90 font-pixel text-[7px] text-cyan-300 px-1 py-0.5 rounded border border-purple-400/40">
                    #{stage.id}
                  </div>
                </div>

                {/* Stage Info */}
                <div>
                  <div className="font-pixel text-[9px] text-cyan-300 truncate" title={stage.title}>
                    {stage.title}
                  </div>
                  <div className="flex items-center justify-between text-[8px] font-screen text-slate-400 mt-0.5">
                    <span>{stage.difficulty}</span>
                    <span>{stage.cols}x{stage.rows}</span>
                  </div>
                </div>

                {/* Stars */}
                <div className="flex items-center justify-between mt-1 pt-1 border-t border-slate-800">
                  <div className="flex items-center gap-0.5">
                    {[1, 2, 3].map((starIdx) => (
                      <Star
                        key={starIdx}
                        className={`w-3 h-3 ${
                          stars >= starIdx
                            ? 'text-yellow-400 fill-yellow-400'
                            : 'text-slate-700'
                        }`}
                      />
                    ))}
                  </div>

                  {isUnlocked && (
                    <span className="font-pixel text-[8px] text-pink-400">
                      {isCurrent ? 'ACTIVE' : 'PLAY'}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer with Direct ZIP Download Buttons for Android */}
        <div className="pt-2 mt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <a
              href="/android_jigsaw_game.zip"
              download="android_jigsaw_game.zip"
              className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-500 to-green-400 hover:from-emerald-400 hover:to-green-300 text-slate-950 font-pixel text-[9px] rounded-lg border border-emerald-200 shadow-[0_0_10px_rgba(16,185,129,0.4)] font-bold active:scale-95 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>DOWNLOAD ANDROID ZIP</span>
            </a>

            <a
              href="/jigsaw_full_source.zip"
              download="jigsaw_full_source.zip"
              className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 font-pixel text-[9px] rounded-lg border border-slate-700 active:scale-95 cursor-pointer"
            >
              <Download className="w-3 h-3 text-cyan-400" />
              <span>SOURCE ZIP</span>
            </a>
          </div>

          <span className="text-[8px] font-screen text-slate-400">
            50 STAGES · 100% OFFLINE READY
          </span>
        </div>
      </div>
    </div>
  );
};
