import React from 'react';
import { Trophy, Star, ArrowRight, RotateCcw, Grid } from 'lucide-react';
import { sound } from '../utils/audio';
import { Stage } from '../types/stages';

interface VictoryModalProps {
  stage: Stage;
  hasNextStage: boolean;
  score: number;
  timeRemaining: number;
  stars: number;
  onNextStage: () => void;
  onReplayStage: () => void;
  onOpenStageSelect: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  stage,
  hasNextStage,
  score,
  timeRemaining,
  stars,
  onNextStage,
  onReplayStage,
  onOpenStageSelect,
}) => {
  const formattedScore = score.toString().padStart(5, '0');
  const timeBonus = timeRemaining * 10;
  const totalScore = (score + timeBonus).toString().padStart(5, '0');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm animate-fadeIn select-none">
      <div className="relative w-full max-w-sm bg-slate-950 border-4 border-yellow-400 p-5 sm:p-6 rounded-2xl shadow-[0_0_35px_rgba(250,204,21,0.5)] text-center overflow-hidden">
        {/* Glow inner line */}
        <div className="absolute inset-0 pointer-events-none border border-cyan-400 m-1 rounded-xl" />

        {/* Animated Stars */}
        <div className="flex justify-center items-center gap-2 mb-2">
          {[1, 2, 3].map((starIdx) => (
            <Star
              key={starIdx}
              className={`w-8 h-8 transition-transform duration-300 ${
                stars >= starIdx
                  ? 'text-yellow-400 fill-yellow-400 animate-bounce'
                  : 'text-slate-700'
              }`}
              style={{ animationDelay: `${starIdx * 0.15}s` }}
            />
          ))}
        </div>

        <h2 className="text-xl sm:text-2xl font-pixel text-yellow-300 tracking-wider mb-1 drop-shadow-[0_0_10px_#facc15]">
          STAGE CLEAR!
        </h2>
        <p className="text-xs font-pixel text-cyan-300 mb-4 tracking-wider">
          {stage.title.toUpperCase()}
        </p>

        {/* Completed Image Thumbnail with Shine */}
        <div className="relative w-36 h-36 mx-auto mb-4 rounded-xl overflow-hidden border-2 border-cyan-400 shadow-[0_0_15px_rgba(0,240,255,0.4)]">
          <img
            src={stage.imageUrl}
            alt={stage.title}
            className="w-full h-full object-cover pixel-crisp"
          />
          <div className="absolute inset-0 bg-gradient-to-tr from-cyan-500/20 to-transparent pointer-events-none" />
        </div>

        {/* Score Breakdown Box */}
        <div className="bg-slate-900 border-2 border-purple-500/60 p-3 rounded-lg mb-4 space-y-1.5 text-left text-xs font-pixel">
          <div className="flex justify-between items-center">
            <span className="text-purple-300 text-[10px]">STAGE SCORE:</span>
            <span className="text-yellow-300">{formattedScore}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-purple-300 text-[10px]">TIME BONUS:</span>
            <span className="text-cyan-300">+{timeBonus}</span>
          </div>
          <div className="border-t border-purple-500/40 pt-1.5 flex justify-between items-center text-sm">
            <span className="text-white text-xs">TOTAL:</span>
            <span className="text-emerald-400 drop-shadow-[0_0_6px_#34d399]">{totalScore}</span>
          </div>
        </div>

        {/* Main Action: Sensible Large NEXT STAGE Button */}
        <div className="flex flex-col gap-2">
          {hasNextStage ? (
            <button
              onClick={() => {
                sound.playBleep();
                onNextStage();
              }}
              className="w-full py-3 px-4 bg-gradient-to-r from-emerald-600 to-green-500 hover:from-emerald-500 hover:to-green-400 text-slate-950 font-pixel text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(16,185,129,0.5)] border-2 border-emerald-300 transition-transform active:scale-95 cursor-pointer font-bold"
            >
              <span>NEXT STAGE</span>
              <ArrowRight className="w-4 h-4 stroke-[3]" />
            </button>
          ) : (
            <div className="w-full py-2.5 bg-yellow-400 text-slate-950 font-pixel text-xs rounded-xl font-bold">
              ALL STAGES COMPLETED! 🏆
            </div>
          )}

          {/* Secondary Actions */}
          <div className="flex gap-2">
            <button
              onClick={() => {
                sound.playBleep();
                onReplayStage();
              }}
              className="flex-1 py-2 px-2 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 rounded-lg font-pixel text-[10px] flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3 text-pink-400" />
              <span>REPLAY</span>
            </button>

            <button
              onClick={() => {
                sound.playBleep();
                onOpenStageSelect();
              }}
              className="flex-1 py-2 px-2 bg-purple-950/70 hover:bg-purple-900 text-purple-200 border border-purple-500/60 rounded-lg font-pixel text-[10px] flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Grid className="w-3 h-3 text-cyan-300" />
              <span>STAGES</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
