import React from 'react';
import { X, Download, FileArchive, CheckCircle, Smartphone, Code } from 'lucide-react';
import { sound } from '../utils/audio';

interface ZipDownloadModalProps {
  onClose: () => void;
}

export const ZipDownloadModal: React.FC<ZipDownloadModalProps> = ({ onClose }) => {
  const handleDownload = (filename: string) => {
    sound.playPickup();
    const link = document.createElement('a');
    link.href = `/${filename}`;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn select-none">
      <div className="relative w-full max-w-lg bg-slate-950 border-4 border-yellow-400 rounded-2xl p-4 sm:p-6 shadow-[0_0_40px_rgba(250,204,21,0.5)] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b-2 border-yellow-400/50 mb-4">
          <div className="flex items-center gap-2">
            <FileArchive className="w-6 h-6 text-yellow-400 animate-pulse" />
            <h2 className="font-pixel text-xs sm:text-sm text-yellow-300 tracking-wider">
              DOWNLOAD ZIP ARCHIVE
            </h2>
          </div>

          <button
            onClick={() => {
              sound.playBleep();
              onClose();
            }}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg bg-slate-900 border border-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <p className="text-slate-300 text-xs font-screen mb-4">
          Choose a ZIP package to download for your Android project or offline play:
        </p>

        {/* Option 1: Android Ready Bundle */}
        <div className="bg-slate-900/90 border-2 border-emerald-400/80 rounded-xl p-3.5 mb-3 flex flex-col gap-2 shadow-[0_0_15px_rgba(16,185,129,0.2)]">
          <div className="flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <h3 className="font-pixel text-[10px] sm:text-xs text-emerald-300">
                1. ANDROID READY ASSETS ZIP
              </h3>
              <p className="text-[10px] text-slate-400 font-screen">
                Ready to unzip directly into Android Studio / Android Gemini agent
              </p>
            </div>
          </div>

          <ul className="text-[9px] text-slate-300 font-screen space-y-1 pl-6 list-disc">
            <li>Includes all 50 progressive jigsaw puzzle stages</li>
            <li>All 12 high-res animal scenes & Web Audio SFX</li>
            <li>100% Full-Screen edge-to-edge for all Android devices</li>
            <li>Includes Android Kotlin code in ANDROID_INTEGRATION.md</li>
          </ul>

          <button
            onClick={() => handleDownload('android_jigsaw_game.zip')}
            className="mt-1 w-full py-2.5 px-4 bg-gradient-to-r from-emerald-500 to-green-400 hover:from-emerald-400 hover:to-green-300 text-slate-950 font-pixel text-[10px] sm:text-xs font-bold rounded-lg border-2 border-emerald-200 shadow-[0_0_15px_rgba(16,185,129,0.5)] flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all"
          >
            <Download className="w-4 h-4 stroke-[3]" />
            <span>DOWNLOAD ANDROID GAME ZIP (12.7 MB)</span>
          </button>
        </div>

        {/* Option 2: Full Source Code */}
        <div className="bg-slate-900/80 border border-cyan-400/60 rounded-xl p-3.5 mb-4 flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <Code className="w-5 h-5 text-cyan-400 shrink-0" />
            <div>
              <h3 className="font-pixel text-[10px] sm:text-xs text-cyan-300">
                2. FULL PROJECT SOURCE CODE ZIP
              </h3>
              <p className="text-[10px] text-slate-400 font-screen">
                Complete React + TypeScript + Vite workspace code
              </p>
            </div>
          </div>

          <button
            onClick={() => handleDownload('jigsaw_full_source.zip')}
            className="mt-1 w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 text-cyan-300 font-pixel text-[9px] sm:text-[10px] rounded-lg border border-cyan-400/50 flex items-center justify-center gap-2 cursor-pointer active:scale-95 transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>DOWNLOAD FULL SOURCE ZIP (12.6 MB)</span>
          </button>
        </div>

        {/* Quick Android Studio instructions */}
        <div className="bg-slate-950/90 rounded-lg p-2.5 border border-slate-800 text-[9px] text-slate-400 font-screen">
          <span className="text-yellow-400 font-pixel text-[8px] block mb-1">
            HOW TO USE IN ANDROID STUDIO:
          </span>
          Extract contents of <code className="text-cyan-300">android_jigsaw_game.zip</code> into <code className="text-cyan-300">app/src/main/assets/jigsaw_game/</code>, then open in WebView with <code className="text-emerald-300">webView.loadUrl("file:///android_asset/jigsaw_game/index.html")</code>.
        </div>
      </div>
    </div>
  );
};
