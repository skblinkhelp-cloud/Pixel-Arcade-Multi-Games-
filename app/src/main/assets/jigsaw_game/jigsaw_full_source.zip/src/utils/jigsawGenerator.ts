// Interlocking Jigsaw Puzzle Geometry Generator

export interface JigsawGridConfig {
  cols: number;
  rows: number;
  width: number;
  height: number;
}

export interface PieceData {
  id: string;
  col: number;
  row: number;
  // Local bounds within the full image
  originX: number;
  originY: number;
  width: number;
  height: number;
  // Polarities: 1 = tab (outward), -1 = hole (inward), 0 = flat border
  top: number;
  right: number;
  bottom: number;
  left: number;
  // SVG Path for the piece shape
  pathD: string;
  // Path for drawing when translated to local (0, 0)
  localPathD: string;
}

// Generate deterministic edge polarities for a grid
export function generateGridPolarities(cols: number, rows: number, seed: number = 42) {
  // Simple pseudo random generator with seed
  let s = seed;
  const rnd = () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };

  // Horizontal edges: rows + 1 lines of cols segments
  // Row 0 is flat (0), row `rows` is flat (0). Interior edges are +1 or -1
  const hEdges: number[][] = [];
  for (let r = 0; r <= rows; r++) {
    hEdges[r] = [];
    for (let c = 0; c < cols; c++) {
      if (r === 0 || r === rows) {
        hEdges[r][c] = 0;
      } else {
        // Preset specific nice shapes or random
        hEdges[r][c] = rnd() > 0.5 ? 1 : -1;
      }
    }
  }

  // Vertical edges: cols + 1 lines of rows segments
  const vEdges: number[][] = [];
  for (let c = 0; c <= cols; c++) {
    vEdges[c] = [];
    for (let r = 0; r < rows; r++) {
      if (c === 0 || c === cols) {
        vEdges[c][r] = 0;
      } else {
        vEdges[c][r] = rnd() > 0.5 ? 1 : -1;
      }
    }
  }

  return { hEdges, vEdges };
}

/**
 * Creates SVG cubic bezier curve for an edge from (x1, y1) to (x2, y2).
 * pol: +1 = outward tab, -1 = inward blank, 0 = flat line
 */
function createEdgePath(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  pol: number,
  tabScale: number = 1
): string {
  if (pol === 0) {
    return `L ${x2.toFixed(2)} ${y2.toFixed(2)}`;
  }

  const dx = x2 - x1;
  const dy = y2 - y1;
  const len = Math.sqrt(dx * dx + dy * dy);
  if (len === 0) return `L ${x2.toFixed(2)} ${y2.toFixed(2)}`;

  // Unit vector along edge
  const ux = dx / len;
  const uy = dy / len;

  // Normal vector pointing to the RIGHT of direction of travel
  // In clockwise traversal:
  // Top edge (L to R): right is DOWN (+Y). If pol = +1 (outward from piece), we want UP (-Y).
  // So outward normal = (-uy, ux) * -1 = (uy, -ux).
  // Let's explicitly define outward normal:
  // When travelling clockwise:
  // Top: (0,0) -> (W,0), dx>0, dy=0. Outward is UP (y < 0).
  // Right: (W,0) -> (W,H), dx=0, dy>0. Outward is RIGHT (x > 0).
  // Bottom: (W,H) -> (0,H), dx<0, dy=0. Outward is DOWN (y > 0).
  // Left: (0,H) -> (0,0), dx=0, dy<0. Outward is LEFT (x < 0).
  // In all 4 cases, OUTWARD is to the LEFT of the direction of travel!
  // Unit normal to the LEFT: nx = uy, ny = -ux
  const nx = uy * pol * tabScale;
  const ny = -ux * pol * tabScale;

  // Point helper: returns [x, y] along baseline + normal offset
  const pt = (u: number, n: number) => {
    const px = x1 + u * len * ux + n * len * nx;
    const py = y1 + u * len * uy + n * len * ny;
    return `${px.toFixed(2)} ${py.toFixed(2)}`;
  };

  // Smooth classical jigsaw tab with round head and pinched neck
  return [
    `L ${pt(0.35, 0)}`,
    `C ${pt(0.37, -0.03)} ${pt(0.38, 0.04)} ${pt(0.39, 0.08)}`,
    `C ${pt(0.40, 0.22)} ${pt(0.45, 0.23)} ${pt(0.50, 0.23)}`,
    `C ${pt(0.55, 0.23)} ${pt(0.60, 0.22)} ${pt(0.61, 0.08)}`,
    `C ${pt(0.62, 0.04)} ${pt(0.63, -0.03)} ${pt(0.65, 0)}`,
    `L ${pt(1.0, 0)}`,
  ].join(' ');
}

// Generate all pieces for a given puzzle configuration
export function generatePuzzlePieces(config: JigsawGridConfig, seed: number = 77): PieceData[] {
  const { cols, rows, width, height } = config;
  const pieceW = width / cols;
  const pieceH = height / rows;
  const { hEdges, vEdges } = generateGridPolarities(cols, rows, seed);

  const pieces: PieceData[] = [];

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const x = c * pieceW;
      const y = r * pieceH;

      // Top: from hEdges[r][c]. Clockwise: (x,y) -> (x+W, y)
      // Positive polarity = outward (up)
      const topPol = hEdges[r][c];
      
      // Right: from vEdges[c+1][r]. Clockwise: (x+W, y) -> (x+W, y+H)
      // Positive polarity = outward (right)
      const rightPol = vEdges[c + 1][r];

      // Bottom: from hEdges[r+1][c]. Clockwise: (x+W, y+H) -> (x, y+H)
      // For bottom edge, between r and r+1:
      // If hEdges[r+1][c] is +1 (meaning downward tab from row r), then for row r it's outward (+1),
      // and for row r+1 it's inward (-1).
      const bottomPol = hEdges[r + 1][c];

      // Left: from vEdges[c][r]. Clockwise: (x, y+H) -> (x, y)
      // If vEdges[c][r] is +1 (meaning rightward tab from col c-1 into col c),
      // then for col c this left edge is inward (-1)!
      // So leftPol = -vEdges[c][r]
      const leftPol = -vEdges[c][r];

      // Full board space path
      const pTop = createEdgePath(x, y, x + pieceW, y, topPol);
      const pRight = createEdgePath(x + pieceW, y, x + pieceW, y + pieceH, rightPol);
      const pBottom = createEdgePath(x + pieceW, y + pieceH, x, y + pieceH, bottomPol);
      const pLeft = createEdgePath(x, y + pieceH, x, y, leftPol);
      const pathD = `M ${x.toFixed(2)} ${y.toFixed(2)} ${pTop} ${pRight} ${pBottom} ${pLeft} Z`;

      // Local space path (normalized with top-left corner at 0, 0)
      const lpTop = createEdgePath(0, 0, pieceW, 0, topPol);
      const lpRight = createEdgePath(pieceW, 0, pieceW, pieceH, rightPol);
      const lpBottom = createEdgePath(pieceW, pieceH, 0, pieceH, bottomPol);
      const lpLeft = createEdgePath(0, pieceH, 0, 0, leftPol);
      const localPathD = `M 0 0 ${lpTop} ${lpRight} ${lpBottom} ${lpLeft} Z`;

      pieces.push({
        id: `piece-${c}-${r}`,
        col: c,
        row: r,
        originX: x,
        originY: y,
        width: pieceW,
        height: pieceH,
        top: topPol,
        right: rightPol,
        bottom: bottomPol,
        left: leftPol,
        pathD,
        localPathD,
      });
    }
  }

  return pieces;
}
